Sudoku.js Demo Page
===================

Simple demo page for the Sudoku puzzle generator and solver library [Sudoku.js](https://github.com/robatron/sudoku.js).

View it live [here](http://htmlpreview.github.com/?https://github.com/robatron/sudoku.js/blob/master/demo/index.html).
